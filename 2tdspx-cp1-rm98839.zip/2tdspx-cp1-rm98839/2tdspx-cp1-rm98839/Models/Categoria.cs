using Microsoft.AspNetCore.Mvc;
namespace _2tdspx_cp1_rm98839.Models;

public class Categoria
{
    public int Id { get; set; }
    public string Nome { get; set; }
}