using Microsoft.AspNetCore.Mvc;
namespace _2tdspx_cp1_rm98839.Controllers;

public class TarefasController : Controller
{
    private readonly MeuDbContext _context;

    public TarefasController(MeuDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var tarefas = _context.Tarefas.ToList();
        return View(tarefas);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Tarefa tarefa)
    {
        if (ModelState.IsValid)
        {
            _context.Tarefas.Add(tarefa);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(tarefa);
    }

    public IActionResult Details(int id)
    {
        var tarefa = _context.Tarefas.FirstOrDefault(t => t.Id == id);
        if (tarefa == null)
        {
            return NotFound();
        }
        return View(tarefa);
    }

    public IActionResult Edit(int id)
    {
        var tarefa = _context.Tarefas.FirstOrDefault(t => t.Id == id);
        if (tarefa == null)
        {
            return NotFound();
        }
        return View(tarefa);
    }

    [HttpPost]
    public IActionResult Edit(Tarefa tarefa)
    {
        if (ModelState.IsValid)
        {
            _context.Tarefas.Update(tarefa);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(tarefa);
    }

    public IActionResult Delete(int id)
    {
        var tarefa = _context.Tarefas.FirstOrDefault(t => t.Id == id);
        if (tarefa == null)
        {
            return NotFound();
        }
        return View(tarefa);
    }

    [HttpPost]
    public IActionResult DeleteConfirmed(int id)
    {
        var tarefa = _context.Tarefas.FirstOrDefault(t => t.Id == id);
        if (tarefa != null)
        {
            _context.Tarefas.Remove(tarefa);
            _context.SaveChanges();
        }
        return RedirectToAction("Index");
    }
}