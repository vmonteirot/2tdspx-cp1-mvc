using Microsoft.AspNetCore.Mvc;
namespace _2tdspx_cp1_rm98839.Controllers;

public class CategoriasController : Controller
{
    private readonly MeuDbContext _context;

    public CategoriasController(MeuDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var categorias = _context.Categorias.ToList();
        return View(categorias);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Categoria categoria)
    {
        if (ModelState.IsValid)
        {
            _context.Categorias.Add(categoria);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(categoria);
    }

    public IActionResult Details(int id)
    {
        var categoria = _context.Categorias.FirstOrDefault(c => c.Id == id);
        if (categoria == null)
        {
            return NotFound();
        }
        return View(categoria);
    }

    public IActionResult Edit(int id)
    {
        var categoria = _context.Categorias.FirstOrDefault(c => c.Id == id);
        if (categoria == null)
        {
            return NotFound();
        }
        return View(categoria);
    }

    [HttpPost]
    public IActionResult Edit(Categoria categoria)
    {
        if (ModelState.IsValid)
        {
            _context.Categorias.Update(categoria);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(categoria);
    }

    public IActionResult Delete(int id)
    {
        var categoria = _context.Categorias.FirstOrDefault(c => c.Id == id);
        if (categoria == null)
        {
            return NotFound();
        }
        return View(categoria);
    }

    [HttpPost]
    public IActionResult DeleteConfirmed(int id)
    {
        var categoria = _context.Categorias.FirstOrDefault(c => c.Id == id);
        if (categoria != null)
        {
            _context.Categorias.Remove(categoria);
            _context.SaveChanges();
        }
        return RedirectToAction("Index");
    }
}